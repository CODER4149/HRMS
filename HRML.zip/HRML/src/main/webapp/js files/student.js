/**
 * 
 */
$(document).ready(function(){
	$("#Work").hide();
	$("#Working").click(function(){
		$("#Work").show();
	});
	$("#Experience").click(function(){
		$("#Work").show();
	});
	$("#Fresher").click(function(){
		$("#Work").hide();
	});
	
});
//$(document).ready(function(){
			//	$("#Work1").hide();
			//	$("#Working1").click(function(){
			//		$("#Work1").show();
				//});
				//$("#Experience1").click(function(){
				//	$("#Work1").show();
			//	});
			//	$("#Fresher1").click(function(){
			//		$("#Work1").hide();
			//	});
			//	var a=document.getElementById("Working1"),b=document.getElementById("Experience1");
			//	
			///	if(a.checked==true || b.checked==true){
			//		$("#Work1").show();
				//}
			//	
		//	});

function f1(){
		var a=document.getElementById("pass_year").value;
		document.getElementById("pass_year1").value=document.getElementById("pass_year").value + "-" +(parseInt(a)+1);
	}
	
	
	function f2(){
					var a=parseInt(document.getElementById("duration1").value);
					document.getElementById("1").innerHTML=a+1;
					document.getElementById("2").innerHTML=a+2;
					document.getElementById("3").innerHTML=a+3;
					document.getElementById("4").innerHTML=a+4;
					document.getElementById("5").innerHTML=a+5;
					document.getElementById("6").innerHTML=a+6;
					document.getElementById("7").innerHTML=a+7;
					document.getElementById("8").innerHTML=a+8;
					document.getElementById("9").innerHTML=a+9;
					document.getElementById("10").innerHTML=a+10;
					document.getElementById("11").innerHTML=a+11;
					document.getElementById("12").innerHTML=a+12;
					document.getElementById("13").innerHTML=a+13;
					document.getElementById("14").innerHTML=a+14;
					document.getElementById("15").innerHTML=a+15;
				}
				
	//	var b=a+1;
		
	//	if(a1!=""){
		//for(i=0; i<10; i++){
			
		//	  var node = document.createElement("option");
		//			node.classList.add("mystyle");
		//	  var textnode = document.createTextNode(b);
		//	  node.appendChild(textnode);
		//	  document.getElementById("Duration2").appendChild(node);
		//    b++;
		//	
		//} 
		//}
		
	//}
	//function f2(){
		
		//var a=document.getElementById("duration1").value;
		//var a1=document.getElementById("Duration2").value;
		//var c=eval("a1-a");
		//if(c>0){
		//document.getElementById("experienced").innerHTML=c+" Years Experienced";
		//}else{
		//	document.getElementById("experienced").innerHTML="Please Choose valid Year";
		//	document.getElementById("experienced").style.color="red";
		//}
		//}
		
function passyear(){
				var a=document.getElementById("pass_year222").value;
				document.getElementById("pass_year111").value=a + "-" +(parseInt(a)+1);
			}
			function getduration(){
				var a=document.getElementById("du").value;
				var b=document.getElementById("D").value;
				console.log(a+".    ."+b);
				document.getElementById("duration3").value=a+"-"+b ;
			}
			$(document).ready(function(){
				$("#Work1").hide();
				$("#Working1").click(function(){
					$("#Work1").show();
				});
				$("#Experience1").click(function(){
					$("#Work1").show();
				});
				$("#Fresher1").click(function(){
					$("#Work1").hide();
				});
				var a=document.getElementById("Working1"),b=document.getElementById("Experience1");
				
				if(a.checked==true || b.checked==true){
					$("#Work1").show();
				}
				
			});
			function mail(f){
				console.log(f);
 						document.getElementById("mail_name").value=f;
					
 						
 					}
			function mail_value55(g){
				console.log(g);
 						
					document.getElementById("name25").value=g;
 						
 					}
function showHint(str, a) {

			var xhttp;

			xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {

					if (this.response == 1) {
						if(a==4){
						document.getElementById("Email").style.borderStyle = "solid";
						document.getElementById("Email").style.borderColor = "red";
						document.getElementById("info").style.display = "block";
						document.getElementById("info").innerHTML = "This email was present in our Data please Insert valid Email";
						document.getElementById("disable_button").disabled = true;
						}
						if(a==7){
							console.log("done");
						document.getElementById("Email1111111").style.borderStyle = "solid";
						document.getElementById("Email1111111").style.borderColor = "red";
						document.getElementById("info7").style.display = "block";
						document.getElementById("info7").innerHTML = "This email was present in our Data please Insert valid Email";
						document.getElementById("update_student").disabled = true;
						console.log("done");
						}
					}
					if (this.response == 3) {
						if(a==5){
						document.getElementById("contact").style.borderStyle = "solid";
						document.getElementById("contact").style.borderColor = "red";
						document.getElementById("info1").style.display = "block";
						document.getElementById("info1").innerHTML = "This Contact was present in our Data please Insert valid Contact";
						document.getElementById("disable_button").disabled = true;
						}
						if(a==8){
						document.getElementById("contact1").style.borderStyle = "solid";
						document.getElementById("contact1").style.borderColor = "red";
						document.getElementById("info8").style.display = "block";
						document.getElementById("info8").innerHTML = "This Contact was present in our Data please Insert valid Contact";
						document.getElementById("update_student").disabled = true;
						}
					}
					console.log(this.response);
				}
			};
			if (a == 7) {
				document.getElementById("Email1111111").style.borderStyle = "none";
				document.getElementById("Email1111111").style.borderColor = "none";
				document.getElementById("info7").style.display = "none";
				//document.getElementById("update_student").disabled = true;
			}
			if (a == 4) {
				document.getElementById("Email").style.borderStyle = "none";
				document.getElementById("Email").style.borderColor = "none";
				document.getElementById("info").style.display = "none";
				document.getElementById("disable_button").disabled = false;
			}
			if (a == 5) {
				document.getElementById("contact").style.borderStyle = "none";
				document.getElementById("contact").style.borderColor = "none";
				document.getElementById("info1").style.display = "none";
				document.getElementById("disable_button").disabled = false;
			}
			if (a == 8) {
				document.getElementById("contact1").style.borderStyle = "none";
				document.getElementById("contact1").style.borderColor = "none";
				document.getElementById("info8").style.display = "none";
				//document.getElementById("update_student").disabled = true;
			}
			xhttp
					.open("GET", "./Email_check?Text=" + str + "&token=" + a,
							true);
			xhttp.send();

		}
		
		function fun2(a){
			document.getElementById("delete").href="./Beforeupdate_student?Id="+a;
		}
		
		function f6(){
 				sessionStorage.setItem("key", "var3");
 			}
 			
 			 $(document).ready(function(){
 	 			if(sessionStorage.getItem("key")!=null){
 	 					$("#Updatemodal").modal('show');
 	 				}
 	 			sessionStorage.removeItem("key");
 	 			});
		
		$(document).ready(function(){
 				
 					$("#callmodal").modal('show');
 				
 				
 			});
		