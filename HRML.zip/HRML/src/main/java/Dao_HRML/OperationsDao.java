package Dao_HRML;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import beanclass.Hrbean;
import beanclass.Organization_bean;
import dbConnectivity.DBConnectivity;
import interface_Dao.Interface_Dao;
import jakarta.servlet.http.HttpSession;

public class OperationsDao implements Interface_Dao {

	DBConnectivity cn = new DBConnectivity();
	Connection con = cn.getConnectivity();

	int a;

	ResultSet b;

	public Hrbean check() {
		String q = "SELECT * FROM `add_hr` ";
		Hrbean bn = new Hrbean();

		try {
			PreparedStatement ps1 = con.prepareStatement(q);
			ResultSet b1 = ps1.executeQuery();
			while (b1.next()) {
				bn.setEmail(b1.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bn;
	}

	public int insert1(Hrbean b) {
		String q = "SELECT * FROM `add_hr`";
		//System.out.println("*******************&&&&&&&&*******");
		try {
			PreparedStatement ps1 = con.prepareStatement(q);
			ResultSet b1 = ps1.executeQuery();
			//System.out.println("after resultset");
			Hrbean b2 = check();
			if (b2.getEmail() == null) {
				//System.out.println("in adding");
				this.a = insert(b);
			} else {
				while (b1.next()) {

					if (b.getEmail().equals(b1.getString(5))) {
						//System.out.println(b1.getString(5) + "*         *" + b.getEmail());
						a = 0;
					} else if (b1.isLast()) {
						//System.out.println("22");
						this.a = insert(b);
						// b=null;
					}
//				System.out.println("in while");

//				System.out.println(b2.getEmail()+"********************");
//				if(b2.getEmail()!=null) {
//					a=0;
//				}
//				else {
//					System.out.println("**************************");
//					this.a=insert(b);
//					
//				}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();

		}

		return a;
	}

	public int insert(Hrbean b) {

		String q = "INSERT INTO add_hr( name, date, Designation, email,contact) VALUES (?,?,?,?,?)";
		try {
			PreparedStatement ps1 = con.prepareStatement(q);
			ps1.setString(1, b.getName());
			ps1.setDate(2, b.getDate());
			ps1.setString(3, b.getChoose());

			ps1.setString(4, b.getEmail());
			ps1.setString(5, b.getContact());
			System.out.println("in process insert");
			ps1.executeUpdate();
			this.a = HR_select(b);
			//System.out.println("process complete");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("after calling through servlet in second method" + " " + a);
		return a;
	}

	public int HR_select(Hrbean bn) {
		int fi = 0;
		String q = "SELECT `id` FROM `add_hr` WHERE  `email` =?";

		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getEmail());
			this.b = ps.executeQuery();
			while (b.next()) {
				fi = b.getInt(1);
			}
			this.a = insert_user_master(bn, fi);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("after calling through servlet in third method " + " " + a);
		return a;
	}

	public int insert_user_master(Hrbean bn, int c) {
		String q = "INSERT INTO `user_master`(`UserName`, `PassWord`, `Roll`, `HR_ID`) VALUES (?,?,?,?) ";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getUsername());
			ps.setString(2, bn.getPassword());
			ps.setInt(3, 2);
			ps.setInt(4, c);
			this.a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("after calling through servlet in fifth" + " " + a);
		return a;
	}

	public ResultSet select() {
		String q = "SELECT * FROM add_hr where status=1";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			this.b = ps.executeQuery();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}

	public int delete(Hrbean bn) {

		String q1 = "DELETE FROM `user_master` WHERE HR_ID=?";
		String q = "UPDATE add_hr SET Status=0 WHERE id=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, Integer.parseInt(bn.getId()));
			this.a = ps.executeUpdate();
			this.a = delete1(bn);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}

	public int delete1(Hrbean bn) {

		String q = "DELETE FROM add_hr where id=?";

		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, Integer.parseInt(bn.getId()));
			this.a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}

	public Hrbean beforeupdate(Hrbean bn) {

		String q = "SELECT *FROM add_hr where id=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			//System.out.println("in prepared");
			ps.setInt(1, Integer.parseInt(bn.getId()));
			this.b = ps.executeQuery();
			while (b.next()) {
				bn.setName(b.getString(2));
				bn.setDate(b.getDate(3));
				bn.setChoose(b.getString(4));
				//System.out.println(b.getString(4));
				bn.setEmail(b.getString(5));

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bn;
	}

	public int update(Hrbean bn) {

		String q = "UPDATE add_hr SET name=?,date=?,Designation=?,email=? WHERE id=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			//System.out.println(Integer.parseInt(bn.getId()));
			ps.setInt(5, Integer.parseInt(bn.getId()));
			//System.out.println(Integer.parseInt(bn.getId()));
			ps.setString(1, bn.getName());
			//System.out.println(bn.getDate());
			ps.setDate(2, bn.getDate());
			//System.out.println(bn.getChoose());
			ps.setString(3, bn.getChoose());
			//System.out.println(bn.getEmail());
			ps.setString(4, bn.getEmail());
			this.a = ps.executeUpdate();
			//System.out.println(a);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return a;
	}

	public int insert_organization(Organization_bean bn) {

		String q1 = "INSERT INTO organization( `Organization Name`, `Address`, `Email`, `Contact No.`) VALUES (?,?,?,?)";
		System.out.println("after insert query");
		try {
			PreparedStatement ps1 = con.prepareStatement(q1);
			ps1.setString(1, bn.getOrganization_name());
			ps1.setString(2, bn.getAddress());
			ps1.setString(3, bn.getEmail());
			ps1.setString(4, bn.getContact());
		//	System.out.println("add data successfully");

			this.a = ps1.executeUpdate();
			this.a = insert_user_pass(bn);
			//System.out.println(" before return a");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;

	}

	public int insert_user_pass(Organization_bean bn) {
		String q = "INSERT INTO user_master( UserName, PassWord, Roll) VALUES (?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getUserName());
			ps.setString(2, bn.getPassWord());
			ps.setInt(3, 1);

			//System.out.println("successs user pass");
			this.a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return a;

	}

	public ResultSet Organization_check_select() {

		String q = "SELECT * FROM `organization` ;";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			this.b = ps.executeQuery();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}

	public Organization_bean Select_org(Organization_bean bn4) {
		String q = "SELECT *FROM organization;";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			this.b = ps.executeQuery();
			while (b.next()) {
				bn4.setId(b.getInt(1));
				bn4.setOrganization_name(b.getString(2));
				bn4.setAddress(b.getString(3));
				
				bn4.setEmail(b.getString(4));
				bn4.setContact(b.getString(5));
				bn4.setStatus(b.getInt(6));

			}
			bn4=select_u_master1(bn4);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bn4;
	}

	
	public Organization_bean select_u_master1(Organization_bean bn4) {
		String q = "SELECT `UserName`, `PassWord` FROM `user_master` WHERE `Roll`=? ";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, 1);
			

			this.b = ps.executeQuery();

			
			while (b.next()) {

				bn4.setUserName(b.getString(1));
				bn4.setPassWord(b.getString(2));

				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bn4;
	}
	
	public int select_u_master(Organization_bean bn4) {
		String q = "SELECT `UserName`, `PassWord` FROM `user_master` WHERE `Roll`=? && `UserName`=? && `PassWord`=?";
		int login_return = 0;
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, bn4.getId());
			ps.setString(2, bn4.getUserName());
			ps.setString(3, bn4.getPassWord());

			this.b = ps.executeQuery();

			Organization_bean bn = new Organization_bean();
			while (b.next()) {

				bn.setUserName(b.getString(1));
				bn.setPassWord(b.getString(2));

				if (bn.getUserName() != null) {
					login_return = 1;

				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println();
		return login_return;
	}

	public int update_Organization(Organization_bean bn) {
		String q = "UPDATE `organization` SET `Organization Name`=?,`Address`=?,`Email`=?,`Contact No.`=?,`STATUS`=? WHERE `Id`=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getOrganization_name());
			ps.setString(2, bn.getAddress());
			ps.setString(3, bn.getEmail());
			ps.setString(4, bn.getContact());
			ps.setInt(5, 1);
			int a3 = Select_org_id(bn);
			ps.setInt(6, a3);
			this.a = ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return a;
	}

	public int Select_org_id(Organization_bean bn) {
		int c3 = 0;
		String q = "SELECT *FROM organization;";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			this.b = ps.executeQuery();
			while (b.next()) {
				c3 = b.getInt(1);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return c3;
	}

	public Organization_bean insert_1(Organization_bean bn) {
		String q = "SELECT  * FROM `student`  ";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			this.b = ps.executeQuery();
			while (b.next()) {

				bn.setPassWord(b.getString(2));
				int i = 0;
				int c1 = bn.getPassWord().length();
				if (bn.getUserName().length() < c1) {
					while (bn.getPassWord().charAt(i) == bn.getUserName().charAt(i)) {
						//System.out.println("i");
						i++;
						return bn;
					}
					//System.out.println(bn.getPassWord());
				} else {
					return bn;
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bn;
	}

	public int email_check(Organization_bean bn) {

		String q = "Select email FROM add_hr where email=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getEmail());
			//System.out.println("in execute Query");
			this.b = ps.executeQuery();
			while (b.next()) {
				Organization_bean bn1 = new Organization_bean();
				bn1.setEmail(b.getString(1));
				//System.out.println(bn1.getEmail());
				if (bn1.getEmail().equals(bn.getEmail())) {
					return 1;
				} else {
					return 0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}

	public int username_check(Organization_bean bn) {
		String q = "Select UserName FROM user_master where UserName=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getEmail());
			//System.out.println("in execute Query");
			this.b = ps.executeQuery();
			while (b.next()) {
				Organization_bean bn1 = new Organization_bean();
				bn1.setEmail(b.getString(1));

				if (bn1.getEmail().equals(bn.getEmail())) {

					return 2;
				} else {

					return 0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}

	public Organization_bean select_u_master_Hr(Organization_bean bn2) {
		String q = "SELECT `UserName`, `PassWord` FROM `user_master` WHERE `Roll`=? && `UserName`=? && `PassWord`=?";

		Organization_bean bn = new Organization_bean();
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, 2);
			ps.setString(2, bn2.getUserName());
			ps.setString(3, bn2.getPassWord());

			this.b = ps.executeQuery();
			//System.out.println(b);

			while (b.next()) {

				bn.setUserName(b.getString(1));
				bn.setPassWord(b.getString(2));
				//System.out.println(bn2.getPassWord());
				//System.out.println(bn.getUserName() + "*       *" + bn.getPassWord());

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bn;
	}

	public int insert_Student(Hrbean bn) {

		String q = "INSERT INTO `student`( `Name`, `Date`, ` Current Location`, `Email`, `Contact No.`, `Gender`, `Status`, `Qualification`, `Duration`, `Designation`, `type`, `Permanent_Location`, `Branch`, `PassOut_Year`, `Certification`, `Certification_place`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getName());
			ps.setDate(2, bn.getDate());
			ps.setString(3, bn.getAddress());
			ps.setString(4, bn.getEmail());
			ps.setString(5, bn.getContact());
			ps.setString(6, bn.getGender());
			ps.setString(7, bn.getStatus());
			
			ps.setString(8, bn.getQualification());
			ps.setString(9, bn.getDuration1());
			ps.setString(10, bn.getDesignation());
			ps.setString(11, bn.getType());
			ps.setString(12, bn.getAddress1());
			ps.setString(13, bn.getBranch());
			ps.setString(14, bn.getPass_year());
			ps.setString(15, bn.getCirtification());
			
			ps.setString(16, bn.getCirtification_place());
			
			
			this.a = ps.executeUpdate();
		} catch (SQLException e) {
			this.a=2;
//			System.out.println(e);
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
		return a;

	}

	public ResultSet select_student(Hrbean bn) {
		String q = "SELECT * FROM `student` where Status_stud=0 ";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			this.b = ps.executeQuery();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

	public int delete_student(Hrbean bn) {
	
		String q = "UPDATE `student` SET `Status_stud`=? WHERE Id=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, 1);
			ps.setInt(2, Integer.parseInt(bn.getId()));
			a = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}

	public Hrbean Beforeupdate_student(Hrbean bn1) {
		String q = "SELECT * FROM `student` WHERE id=? ";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, Integer.parseInt(bn1.getId()));
			b = ps.executeQuery();
			while (b.next()) {
				bn1.setId(b.getString(1));
				bn1.setName(b.getString(2));
				bn1.setDate(b.getDate(3));
				bn1.setAddress(b.getString(4));
				bn1.setEmail(b.getString(5));
				bn1.setContact(b.getString(6));
				bn1.setGender(b.getString(7));
				bn1.setStatus(b.getString(8));
				bn1.setQualification(b.getString(9));
				bn1.setDuration1(b.getString(10));
				bn1.setDesignation(b.getString(11));
				bn1.setType(b.getString(12));
				bn1.setAddress1(b.getString(13));
				bn1.setBranch(b.getString(14));
				bn1.setPass_year(b.getString(15));
				bn1.setCirtification(b.getString(16));
				//System.out.println("this id the cirtificate"+bn1.getCirtification());
				bn1.setCirtification_place(b.getString(17));
				
//				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bn1;
	}

	public int Update_student(Hrbean bn) {
		String q = "UPDATE `student` SET `Name`=?,`Date`=?,` Current Location`=?,`Email`=?,`Contact No.`=?,`Gender`=?,`Status`=?,`Qualification`=?,`Duration`=?,`Designation`=?,`type`=?,`Permanent_Location`=?,`Branch`=?,`PassOut_Year`=?,`Certification`=?,`Certification_place`=? WHERE `Id`=?";

		try {
			PreparedStatement ps = con.prepareStatement(q);
			
			ps.setInt(17, Integer.parseInt(bn.getId()));
			ps.setString(1, bn.getName());
			ps.setDate(2, bn.getDate());
			ps.setString(3, bn.getAddress());
			ps.setString(4, bn.getEmail());
			ps.setString(5, bn.getContact());
			ps.setString(6, bn.getGender());
			ps.setString(7, bn.getStatus());
			
			ps.setString(8, bn.getQualification());
			ps.setString(9, bn.getDuration1());
			ps.setString(10, bn.getDesignation());
			System.out.println("ddddd"+bn.getDesignation());
			ps.setString(11, bn.getType());
			ps.setString(12, bn.getAddress1());
			ps.setString(13, bn.getBranch());
			ps.setString(14, bn.getPass_year());
			ps.setString(15, bn.getCirtification());
			
			ps.setString(16, bn.getCirtification_place());
			a = ps.executeUpdate();
			return a;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
	public int contact_check(Organization_bean bn) {
		String q = "SELECT  `Contact` FROM `add_hr` WHERE `Contact`=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getEmail());
			//System.out.println("in execute Query");
			this.b = ps.executeQuery();
			while (b.next()) {
				Organization_bean bn1 = new Organization_bean();
				bn1.setEmail(b.getString(1));

				if (bn1.getEmail().equals(bn.getEmail())) {
					//System.out.println("return 3");
					return 3;
					
				} else {

					return 0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
	public int student_email_check(Organization_bean bn) {
		String q = "SELECT  `Email` FROM `student` WHERE `Email`=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getEmail());
			//System.out.println("in execute Query");
			this.b = ps.executeQuery();
			while (b.next()) {
				Organization_bean bn1 = new Organization_bean();
				bn1.setEmail(b.getString(1));

				if (bn1.getEmail().equals(bn.getEmail())) {
					//System.out.println("return 3");
					return 1;
					
				} else {

					return 0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
	public int student_contact_check(Organization_bean bn) {
		String q = "SELECT  `Contact No.` FROM `student` WHERE `Contact No.`=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getEmail());
			//System.out.println("in execute Query");
			this.b = ps.executeQuery();
			while (b.next()) {
				Organization_bean bn1 = new Organization_bean();
				bn1.setEmail(b.getString(1));

				if (bn1.getEmail().equals(bn.getEmail())) {
					//System.out.println("return 3");
					return 3;
					
				} else {

					return 0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
	
	public Organization_bean gethrname(Organization_bean bn4) {
		String q="SELECT `HR_ID` FROM `user_master` WHERE  `UserName`=?, `STATUS`=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn4.getUserName());
			ps.setInt(2, 1);
			this.b = ps.executeQuery();
			while(b.next()) {
				bn4.setId(b.getInt(1));
			}
			bn4=gethrname1(bn4);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
//			e.printStackTrace();
		}
		return bn4;
	}

	public Organization_bean gethrname1(Organization_bean bn4) {
		String q="SELECT  `name` FROM `add_hr` WHERE `id`=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1, bn4.getId());
			this.b = ps.executeQuery();
			while(b.next()) {
				bn4.setUserName(b.getString(1));
				System.out.println(b.getString(1)+".   this is username");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bn4;
	}
	public int call_log(Hrbean b) {
		String q="INSERT INTO `call_log`( `name`, `date_today`, `info`, `call_date`,`call_id`) VALUES (?,?,?,?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, b.getName());
			System.out.println("name"+b.getName());
			ps.setDate(2, b.getDate());
			System.out.println("date1"+b.getDate());
			ps.setString(3, b.getAddress());
			System.out.println("address"+b.getAddress());
			ps.setDate(4, b.getDate2());
			System.out.println("date2"+b.getDate2());
			System.out.println("id33333333333"+b.getId());
			ps.setInt(5, Integer.parseInt(b.getId()));
			
			
			this.a=ps.executeUpdate();
			System.out.println("return int into calllog"+" "+a);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return a;
	}
	public ArrayList call_log_fetch(Hrbean bn ) {
		String q="SELECT * FROM `call_log` WHERE `call_id`=?";
		System.out.println("this is in fetch"+""+bn.getId());
		
		ArrayList<Hrbean> obj_call1=new ArrayList<Hrbean>();
		System.out.println("object in array list"+obj_call1);
		
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1,Integer.parseInt(bn.getId()) );
			
			this.b = ps.executeQuery();
			//System.out.println("resultset"+ b.getInt(1));
			
			
			while(b.next()) {
				//System.out.println("resultset value in fetch data  ."+ b.getInt(1));
			//	System.out.println("resultset value in fetch data  ."+ b.getString(2));
				//System.out.println("resultset value in fetch data  ."+ b.getDate(3));
				//System.out.println("resultset value in fetch data  ."+ b.getString(4));
				//System.out.println("resultset value in fetch data  ."+ b.getDate(5));
				Hrbean bn1=new Hrbean();
				bn1.setName(b.getString(2));
				
				bn1.setDate(b.getDate(3));
				System.out.println("name of stud call"+bn.getDate());
				bn1.setAddress(b.getString(4));
				bn1.setDate2(b.getDate(5));
				System.out.println("name of stud call"+bn.getDate2());
				obj_call1.add(bn1);
				
				
				
//				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return obj_call1;
	}
	public int call_log_fetch1(Hrbean bn ) {
		String q="SELECT * FROM `call_log` WHERE `call_id`=?";
		//System.out.println("this is in fetch"+bn.getId());
		this.a=0;
		
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1,Integer.parseInt(bn.getId()) );
			
			this.b = ps.executeQuery();
			while(b.next()) {
				//System.out.println("value of"+bn.getId()+"in value of student name"+b.getString(2));
				a++;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return a;
	}
	public Hrbean col_log_fetch_bean(Hrbean bn) {
		String q="SELECT * FROM `call_log` WHERE `call_id`=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1,Integer.parseInt(bn.getId()) );
			
			this.b = ps.executeQuery();
			while(b.next()) {
				bn.setName(b.getString(2));
				
		}
			System.out.println("this is the bean name in sort problem"+bn.getName());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bn;
	}
	
	public Hrbean fetch_student(Hrbean bn) {
		String q="SELECT * FROM `student` WHERE Id=?";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setInt(1,Integer.parseInt(bn.getId()) );
			
			this.b = ps.executeQuery();
			while(b.next()) {
				bn.setName(b.getString(2));
				
		}
			System.out.println("this is the bean name "+bn.getName());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bn;
	}
	
	public int recover_password(Hrbean bn) {
		int z=0;
		String q = "SELECT Id from user_master WHERE HR_ID=(select hr.id from add_hr as hr  WHERE hr.email=?);";
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1,bn.getEmail());
			
			this.b = ps.executeQuery();
			while(b.next()) {
				bn.setId_user(b.getInt(1));
				
		}
			this.a=fetch_id(bn);
			System.out.println("this is the bean name "+bn.getName());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
		
	}
	
	public int fetch_id(Hrbean bn) {
		String q="UPDATE `user_master` SET `PassWord`=? WHERE Id=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(q);
			ps.setString(1, bn.getPassword());
		
			ps.setInt(2, bn.getId_user());
//			System.out.println("date1"+b.getDate());
//			
//			ps.setInt(5, Integer.parseInt(b.getId()));
//			
			
			this.a=ps.executeUpdate();
//			System.out.println("return int into calllog"+" "+a);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	
		return a;
		
	}
}
