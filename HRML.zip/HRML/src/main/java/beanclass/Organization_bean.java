package beanclass;

public class Organization_bean {
	
		private String Organization_name;
		
		private int Roll_org=1;
		private int Id;
		private int Status;
		private String num;
		public String getNum() {
			return num;
		}
		public void setNum(String num) {
			this.num = num;
		}
		public int getId() {
			return Id;
		}
		public int getStatus() {
			return Status;
		}
		public void setStatus(int status) {
			Status = status;
		}
		public void setId(int id) {
			Id = id;
		}
		public int getRoll_org() {
			return Roll_org;
		}
		public String getUserName() {
			return UserName;
		}
		public void setUserName(String userName) {
			UserName = userName;
		}
		public String getPassWord() {
			return PassWord;
		}
		public void setPassWord(String passWord) {
			PassWord = passWord;
		}
	
		
		private String address;
		private String email;
		private String contact;
		private String UserName;
		private String PassWord;
		public String getOrganization_name() {
			return Organization_name;
		}
		public void setOrganization_name(String organization_name) {
			Organization_name = organization_name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getContact() {
			return contact;
		}
		public void setContact(String contact) {
			this.contact = contact;
		}
		
		

}
