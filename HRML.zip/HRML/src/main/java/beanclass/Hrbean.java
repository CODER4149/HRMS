package beanclass;

import java.sql.Date;

public class Hrbean {
	
	private String id;
	private String gender;
	private String address1;
	private String duration1;
	private String duration2;
	private int increment_call,id_user;
	
	public int getIncrement_call() {
		return increment_call;
	}
	public void setIncrement_call(int increment_call) {
		this.increment_call = increment_call;
	}
	public int getId_user() {
		return id_user;
	}
	public void setId_user(int id_user) {
		this.id_user = id_user;
	}
	private String designation;
	private String type;
	private String cirtification;
	private String cirtification_place;
	private String branch;
	private String pass_year;
	public String getPass_year() {
		return pass_year;
	}
	public void setPass_year(String pass_year) {
		this.pass_year = pass_year;
	}
	public String getDuration1() {
		return duration1;
	}
	public void setDuration1(String duration1) {
		this.duration1 = duration1;
	}
	public String getDuration2() {
		return duration2;
	}
	public void setDuration2(String duration2) {
		this.duration2 = duration2;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCirtification() {
		return cirtification;
	}
	public void setCirtification(String cirtification) {
		this.cirtification = cirtification;
	}
	public String getCirtification_place() {
		return cirtification_place;
	}
	public void setCirtification_place(String cirtification_place) {
		this.cirtification_place = cirtification_place;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	private String city;
	private String qualification;
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	private String name;
	private Date date;
	private Date date2;
	public Date getDate2() {
		return date2;
	}
	public void setDate2(Date date2) {
		this.date2 = date2;
	}
	private String choose;
	private String username;
	private String password;
	private String email;
	private String status;
	private String address;
	private String contact;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Hrbean [id=" + id + ", name=" + name + ", date=" + date + ", choose=" + choose + ", username="
				+ username + ", password=" + password + ", email=" + email + ", status=" + status + ", address="
				+ address + ", contact=" + contact + "]";
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getChoose() {
		return choose;
	}
	public void setChoose(String choose) {
		this.choose = choose;
	}
	public String getUsername() {			
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

}
