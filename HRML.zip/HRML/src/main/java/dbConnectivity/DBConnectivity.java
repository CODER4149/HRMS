package dbConnectivity;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnectivity {

	Connection con;
	
	public Connection getConnectivity(){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hrml","root","");
			System.out.println("connection established:");
			
		} catch (Exception e) {
			System.out.println("connection not established:");
			e.printStackTrace();
		}
	
	
	return con;
	}
}
