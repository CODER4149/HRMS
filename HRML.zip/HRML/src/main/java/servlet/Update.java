package servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Update
 */
@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String id=request.getParameter("dao_id1");
		String name=request.getParameter("name");
		String date=request.getParameter("date");
		java.sql.Date date_sql=null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); // your template here
		java.util.Date dateStr;
		try {
			dateStr = formatter.parse(date);
			date_sql = new java.sql.Date(dateStr.getTime());
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String Designation=request.getParameter("designation");
		String email=request.getParameter("email");
		
		Hrbean bn=new Hrbean();
		
		bn.setId(id);
		System.out.println(bn.getId());
		bn.setName(name);
	
		bn.setDate(date_sql);
		
		bn.setChoose(Designation);
		
		bn.setEmail(email);
		Interface_Dao op=new OperationsDao();
		int y=op.update(bn);
		System.out.println(y);
		if(y==1) {
			
			request.setAttribute("a2", "Updated successfully!");
//			RequestDispatcher rd=request.getRequestDispatcher("/AddHr.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/AddHr.jsp");
			
		}
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
	}

}
