package servlet;

import java.io.IOException;
import java.sql.ResultSet;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Beforeupdate
 */
@WebServlet("/Beforeupdate")
public class Beforeupdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String id= request.getParameter("id");
		System.out.println("in get id ");
		Hrbean bn=new Hrbean();
		bn.setId(id);
		Interface_Dao op=new OperationsDao();
		Hrbean y=op.beforeupdate(bn);
		if(y!=null) {
			
			request.setAttribute("a1", y);
		
			RequestDispatcher rd=request.getRequestDispatcher("/AddHr.jsp");
			rd.include(request, response);
			
		}
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
	}



}
