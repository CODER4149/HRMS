package servlet;

import java.io.IOException;

import Dao_HRML.OperationsDao;
import beanclass.Organization_bean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class update_Organization
 */
@WebServlet("/update_Organization")
public class update_Organization extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		String email=request.getParameter("email");
		String contact=request.getParameter("contact");
		String UserName=request.getParameter("UserName");
		String PassWord=request.getParameter("PassWord");
		
		
		
		
		Organization_bean bn=new Organization_bean();
		bn.setOrganization_name(name);
		bn.setAddress(address);
		bn.setEmail(email);
		bn.setContact(contact);
		bn.setUserName(UserName);
		bn.setPassWord(PassWord);
		
		System.out.println("in Dao");
		Interface_Dao op=new OperationsDao();
		System.out.println("in function Dao");
		int y=op.update_Organization(bn);
		if(y==1) {
			
			request.setAttribute("a1", "New Organization Added Successfully Information is successfully Added!");
			RequestDispatcher rd=request.getRequestDispatcher("/update_Organization.jsp");
			rd.include(request, response);
			
		}else {
			request.setAttribute("a1", "This Information is Already In Your DataBase!");
			RequestDispatcher rd=request.getRequestDispatcher("/update_Organization.jsp");
			rd.include(request, response);
			}
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
		}
	}


