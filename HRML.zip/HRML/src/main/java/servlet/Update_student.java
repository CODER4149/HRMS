package servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Update_student
 */
@WebServlet("/Update_student")
public class Update_student extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String Id=request.getParameter("id1");
		String name=request.getParameter("name1");//a
		String date=request.getParameter("dob1");//a
		java.util.Date date1=null;
		java.sql.Date dateDB=null;
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); // your template here
		java.util.Date dateStr;
		try {
			dateStr = formatter.parse(date);
			 dateDB = new java.sql.Date(dateStr.getTime());
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		String email=request.getParameter("email1");//a
		
		String phone=request.getParameter("phone1");//a
		String gender=request.getParameter("gender1");//a
		
		
		
		
		String status=request.getParameter("status1");//a
		String Duration=request.getParameter("Duration11");//a
		
//		String Duration2=request.getParameter("Duration21");//a
//		System.out.println(Duration1 +".   ."+Duration2);
//		String Duration = Duration1+"-"+Duration2;
		System.out.println(Duration);
		String Designation=request.getParameter("Designation1");//a
		System.out.println(Designation);
		String type=request.getParameter("type1");
		String branch=request.getParameter("Branch1");
		String address1=request.getParameter("address1");//a
		String address2=request.getParameter("address21");//a
		String pass_year=request.getParameter("pass_year11");
		String Education=request.getParameter("Education1");//a
		String Certification=request.getParameter("certification1");
		String Certification_Place=request.getParameter("Certification_Place1");
		
		Hrbean bn=new Hrbean();
		
		
		
		bn.setId(Id);
		bn.setName(name);
		bn.setDate(dateDB);
		bn.setAddress(address1);
		bn.setAddress1(address2);
		bn.setContact(phone);
		bn.setEmail(email);
		bn.setGender(gender);
		bn.setDuration1(Duration);
		
		bn.setDesignation(Designation);
		bn.setType(type);
		bn.setBranch(branch);
		bn.setPass_year(pass_year);
		bn.setCirtification(Certification);
		bn.setCirtification_place(Certification_Place);
		bn.setQualification(Education);
		bn.setStatus(status);
		
		Interface_Dao op=new OperationsDao();
		int y=op.Update_student(bn);
		
		if(y==1) {
			request.setAttribute("a2", "Updated successfully!");
			RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");
			rd.include(request, response);
//			response.sendRedirect("/HRML/Blank.jsp");
		}else {
			request.setAttribute("a2", "No row found!");
			RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");
			rd.include(request, response);
		}
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
	}

}
