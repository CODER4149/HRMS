package servlet;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class recover_pass
 */
@WebServlet("/recover_pass")
public class recover_pass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public recover_pass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String password=request.getParameter("password1");
		String email=request.getParameter("email1");
		
		Hrbean bn=new Hrbean();
		bn.setEmail(email);
		bn.setPassword(password);
		
		Interface_Dao op=new OperationsDao();
		int a=op.recover_password(bn);
		if(a==1) {
			System.out.println("updated");
		}else {
			System.out.println("not updated");
		}
	}

}
