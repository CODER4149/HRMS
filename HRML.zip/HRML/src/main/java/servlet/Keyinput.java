package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import Dao_HRML.OperationsDao;
import beanclass.Organization_bean;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Keyinput
 */
@WebServlet("/Keyinput")
public class Keyinput extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String q=request.getParameter("q");
		
		Organization_bean bn=new Organization_bean();
		bn.setUserName(q);
		
		OperationsDao op=new OperationsDao();
		bn=op.insert_1(bn);
		PrintWriter pw=response.getWriter();
		pw.println(bn.getPassWord());
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
	}

	

}
