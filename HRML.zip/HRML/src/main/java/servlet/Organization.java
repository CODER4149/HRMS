package servlet;

import java.io.IOException;
import java.sql.ResultSet;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import beanclass.Organization_bean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Organization
 */
@WebServlet("/Organization")
public class Organization extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		String email=request.getParameter("email");
		String contact=request.getParameter("contact");
		String UserName=request.getParameter("UserName");
		String PassWord=request.getParameter("PassWord");
		String Status=request.getParameter("Status");
	
	
		
		Organization_bean bn=new Organization_bean();
		bn.setOrganization_name(name);
		bn.setAddress(address);
		bn.setEmail(email);
		bn.setContact(contact);
		bn.setUserName(UserName);
		bn.setPassWord(PassWord);
	
		System.out.println("in Dao");
		Interface_Dao op=new OperationsDao();
		
		 Interface_Dao op3=new OperationsDao();
 		Organization_bean bn9=new Organization_bean();
		
 		bn9=op3.Select_org(bn9);
		
		int y=0;
		if(bn9.getEmail()==null){
			System.out.println("in insert");
			 y=op.insert_organization(bn);
		}else {
		 y=op.update_Organization(bn);
		 System.out.println("in update");
		}
		if(y==1) {
			if(bn9.getEmail()==null){
			request.setAttribute("a1", "New Organization Added Successfully !");
			}else {
				request.setAttribute("a1", "Organization Updated Successfully !");
			}
			RequestDispatcher rd=request.getRequestDispatcher("/organization.jsp");
			rd.include(request, response);
			
		}else {
			request.setAttribute("a1", "This Information is Already In Your DataBase!");
			RequestDispatcher rd=request.getRequestDispatcher("/organization.jsp");
			rd.include(request, response);
			}
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
		}
	}


