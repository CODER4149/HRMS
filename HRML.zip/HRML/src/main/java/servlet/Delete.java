package servlet;

import java.io.IOException;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String id= request.getParameter("id");
		Hrbean bn=new Hrbean();
		bn.setId(id);
		Interface_Dao op=new OperationsDao();
		int y=op.delete(bn);
		if(y==1) {
			
			request.setAttribute("a1", "Deleted SuccessFully!");
//			RequestDispatcher rd=request.getRequestDispatcher("/AddHr.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/AddHr.jsp");
			
		}
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
	}

}
