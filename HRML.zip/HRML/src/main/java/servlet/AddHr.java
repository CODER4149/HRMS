package servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class AddHr
 */
@WebServlet("/AddHr")
public class AddHr extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
//		System.out.println(session);
		String name=request.getParameter("name");
		String date=request.getParameter("date");
		java.util.Date date1=null;
		java.sql.Date dateDB=null;
		String addres=request.getParameter("dob");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); // your template here
		java.util.Date dateStr;
		try {
			dateStr = formatter.parse(date);
			 dateDB = new java.sql.Date(dateStr.getTime());
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String choose=request.getParameter("Designation");
		System.out.println(choose);
		String email=request.getParameter("email");
		String contact=request.getParameter("contact");
		String status=request.getParameter("status");
		String password=request.getParameter("password");
		System.out.println(password);
		String username=request.getParameter("username");
		
		Hrbean bn=new Hrbean();
		bn.setName(name);
		bn.setDate(dateDB);
		bn.setChoose(choose);
		bn.setStatus(status);
		bn.setEmail(email);
		bn.setContact(contact);
		bn.setUsername(username);
		bn.setPassword(password);
		
		Interface_Dao op=new OperationsDao();
		int y=0;
		if(bn.getEmail()!=null) {
			System.out.println("before in dao hr");
		 y=op.insert1(bn);
		 
		}
		System.out.println(y);
		if(y==1) {
			
			request.setAttribute("a2", "New HR Information is successfully Added!");
			RequestDispatcher rd=request.getRequestDispatcher("/AddHr.jsp");
			rd.forward(request, response);
//			response.sendRedirect("/HRML/AddHr.jsp");
			
		}
		else {
			request.setAttribute("a2", "This Information is Already In Your DataBase!");
			RequestDispatcher rd=request.getRequestDispatcher("/AddHr.jsp");
			rd.forward(request, response);
//			response.sendRedirect("/HRML/AddHr.jsp");
		}
		
	}
	else  {
//		RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//		rd.include(request, response);
		response.sendRedirect("/HRML/login.jsp");
		
	}
//	}
	}}
