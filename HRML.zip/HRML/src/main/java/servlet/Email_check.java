package servlet;

import java.io.IOException;

import Dao_HRML.OperationsDao;
import beanclass.Organization_bean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.PrintWriter;

/**
 * Servlet implementation class Email_check
 */
@WebServlet("/Email_check")
public class Email_check extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
		System.out.println(session);
//		if(session.getAttribute("role")!=null) {
		String Email=request.getParameter("Text");
		String token=request.getParameter("token");
		System.out.println(token);
		Organization_bean bn=new Organization_bean();
		bn.setEmail(Email);
		bn.setUserName(token);
		Interface_Dao in=new OperationsDao();
		
									
		if(bn.getUserName().equals("0")){
//		
		int y=in.email_check(bn);
		if(y==1) {
			PrintWriter pw=response.getWriter();
		System.out.println(y+"   ---");
			pw.println(y);
		}
	}
		if(bn.getUserName().equals("1")){
		int y=in.username_check(bn);
		
	if(y==2) {
		PrintWriter pw=response.getWriter();
		pw.println(y);
	}
	}
		if(bn.getUserName().equals("3")){
			int y=in.contact_check(bn);
			
		if(y==3) {
			PrintWriter pw=response.getWriter();
			pw.println(y);
		}
		}
		if(bn.getUserName().equals("5")){
			System.out.println("before dao contact");
			int y=in.student_contact_check(bn);
			System.out.println("after dao contact");
		if(y==3) {
			PrintWriter pw=response.getWriter();
			pw.println(y);
		}
		}
		if(bn.getUserName().equals("8")){
			System.out.println("before dao contact");
			int y=in.student_contact_check(bn);
			System.out.println("after dao contact");
		if(y==3) {
			PrintWriter pw=response.getWriter();
			pw.println(y);
		}
		}
		if(bn.getUserName().equals("4") ){
			System.out.println("before dao email");
			int y=in.student_email_check(bn);
			System.out.println("after dao email");
		if(y==1) {
			PrintWriter pw=response.getWriter();
			pw.println(y);
		}
		}
		if(bn.getUserName().equals("7") ){
			System.out.println("before dao email");
			int y=in.student_email_check(bn);
			System.out.println("after dao email");
		if(y==1) {
			PrintWriter pw=response.getWriter();
			pw.println(y);
		}
		}
//		}
//		else  {
////			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
////			rd.include(request, response);
//			response.sendRedirect("/HRML/login.jsp");
//			
//		}
	}
}


