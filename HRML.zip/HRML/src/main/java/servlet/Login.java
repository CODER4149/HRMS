package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import beanclass.Organization_bean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 response.setContentType("text/html");  
		    PrintWriter out = response.getWriter();  
		          
		    String n=request.getParameter("username");  
		    String p=request.getParameter("userpass");  
		    HttpSession session = request.getSession(true);
		    session.setAttribute("username", n);
		  
		    Interface_Dao op5=new OperationsDao();
		    Organization_bean bn4=new Organization_bean();
		    bn4.setUserName(n);
		    bn4.setPassWord(p);
		    bn4.setId(1);
		    int c=op5.select_u_master(bn4);
		    Interface_Dao op6=new OperationsDao();
		    Organization_bean bn=new Organization_bean();
		    bn.setUserName(n);
		    bn.setPassWord(p);
		    bn.setId(2);
		    bn=op6.select_u_master_Hr(bn4);
		   
		    if(c==1) {
		    	session.setAttribute("role", "1");
		    	request.setAttribute("a2", "Welcome");
		    	 RequestDispatcher rd=request.getRequestDispatcher("/organization.jsp");  
			        rd.forward(request, response);
		    } else if(bn.getUserName()!=null && (bn.getUserName().equals(n) && bn.getPassWord().equals(p)) )  {
		    	session.setAttribute("role", "2");
		    request.setAttribute("a2", "Welcome");
	        RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");  
	        rd.forward(request, response);  
		    
		       
		    }
		    else {  
		       request.setAttribute("a11", "Sorry Invalid UserName and Password !");
		        RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");  
		        rd.include(request, response);  
		                      
		        }  
		    
		    }  
	
	}


