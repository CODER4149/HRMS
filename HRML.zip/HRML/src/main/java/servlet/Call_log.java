package servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Call_log
 */
@WebServlet("/Call_log")
public class Call_log extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String id=request.getParameter("stud_id");
		String name=request.getParameter("name_call");
		String Date=request.getParameter("date_today");
		System.out.println("date before bean"+Date);
		String body=request.getParameter("call_body");
		String nextcall=request.getParameter("date_call");
		System.out.println("date before bean"+nextcall);
		
		java.sql.Date dateDB=null,dateDB1=null;
		String addres=request.getParameter("dob");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); // your template here
		java.util.Date dateStr,date_next;
		try {
			dateStr = formatter.parse(Date);
			 dateDB = new java.sql.Date(dateStr.getTime());
			 System.out.println("date 1 in call log"+dateDB);
			 date_next = formatter.parse(nextcall);
			 dateDB1 = new java.sql.Date(date_next.getTime());
			 System.out.println("date 2 in call log"+dateDB1);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		Hrbean bn=new Hrbean();
		bn.setId(id);
		bn.setName(name);
		//System.out.println("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr"+bn.getName());
		bn.setDate(dateDB);
		System.out.println("date 1"+ bn.getDate());
		bn.setAddress(body);
		System.out.println(bn.getAddress());
		bn.setDate2(dateDB1);
		System.out.println("date 2"+ bn.getDate2());
		
		Interface_Dao op=new OperationsDao();
		int y=op.call_log(bn);
		if(y==1) {
			RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");
			rd.forward(request, response);
		}
		
		
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
	}

}
