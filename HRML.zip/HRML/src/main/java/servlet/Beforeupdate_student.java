package servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Beforeupdate_student
 */
@WebServlet("/Beforeupdate_student")
public class Beforeupdate_student extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
//		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String id=request.getParameter("id");
		String Id=request.getParameter("Id");
		String Id1=request.getParameter("id1");
		System.out.println("id of modal call"+Id1);
		OperationsDao bb=new OperationsDao();//tis is the withuot using interface
		Hrbean bn=new Hrbean();
		bn.setId(Id);
		Hrbean bn1=new Hrbean();
		bn1.setId(id);
		Hrbean bn2=new Hrbean();
		bn2.setId(Id1);
		
		//System.out.println("in bean modal value"+bn2.getId());
		int y=0;
		Interface_Dao op=new OperationsDao();
		ArrayList<Hrbean> obj_call3=null;
		if(bn2.getId()!=null) {
			System.out.println("enter in call fetch");
			
			bn2=bb.col_log_fetch_bean(bn2);
			if(bn2.getName()!=null) {
			obj_call3=op.call_log_fetch(bn2);
			}else {
				request.setAttribute("ResultS44et1", obj_call3);
				request.setAttribute("beany",Id1);
				
				RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");
				rd.include(request, response);
			}
			System.out.println("exit in call fetch");
			//try {
				//System.out.println("exit in call fetch"+rs3.getString(2));
			//} catch (SQLException e) {
				//// TODO Auto-generated catch block
			//	e.printStackTrace();
			//}
		}
		if(Id!=null) {
		 y=op.delete_student(bn);
		}else if(id!=null) {
			 bn1=op.Beforeupdate_student(bn1);
			 String a=bn1.getDuration1(),b="",c="";
			// System.out.println(bn1.getCirtification());
				//System.out.print(val1);
				char arr[] = a.toCharArray();
				//System.out.print(arr);
		for(int i=0;i<arr.length;i++){
			if(arr[i]=='-'){
				//System.out.print(arr[i]+"\n");
				c=c+arr[i+1]+arr[i+2]+arr[i+3]+arr[i+4];
				break;
			}else {
				b=b+arr[i];
			}
		}
		//System.out.println(b+"  .  ."+c);	
		bn1.setDuration1(b);
		bn1.setDuration2(c);
			 
			 	request.setAttribute("a1", bn1);
				
				RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");
				rd.include(request, response);
		}
		if(y==1) {
			response.sendRedirect("/HRML/Blank.jsp");
		}
		if(obj_call3!=null) {
			
			request.setAttribute("ResultS44et1", obj_call3);
			bn2=bb.fetch_student(bn2);
			System.out.println("this is the name of the student fetch by without using interface"+bn2.getName());
			//System.out.println("this is rs in server"+rs3);
			request.setAttribute("beany",Id1);
			System.out.println("nnnnnnnnnnnnnnnnnnnn444444$4$$$$$"+bn2.getName());
			request.setAttribute("name_stu",bn2.getName());
			RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");
			rd.include(request, response);
		}
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
	}

}
