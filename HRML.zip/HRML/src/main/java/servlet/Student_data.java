package servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import Dao_HRML.OperationsDao;
import beanclass.Hrbean;
import interface_Dao.Interface_Dao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Student_data
 */
@WebServlet("/Student_data")
public class Student_data extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(false);
		
		System.out.println(session);
		if(session.getAttribute("role")!=null) {
		String name=request.getParameter("name");//a
		String date=request.getParameter("dob");//a
		java.util.Date date1=null;
		java.sql.Date dateDB=null;
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); // your template here
		java.util.Date dateStr;
		try {
			dateStr = formatter.parse(date);
			 dateDB = new java.sql.Date(dateStr.getTime());
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		String email=request.getParameter("email");//a
		String phone=request.getParameter("phone");//a
		String gender=request.getParameter("gender");//a
		
		
		
		
		String status=request.getParameter("status");//a
		String Duration1=request.getParameter("Duration1");//a
		String Duration2=request.getParameter("Duration2");//a
		String Duration = Duration1+"-"+Duration1;
		String Designation=request.getParameter("Designation");//a
		String type=request.getParameter("type1");
		String branch=request.getParameter("Branch");
		String address1=request.getParameter("address1");//a
		String address2=request.getParameter("address2");//a
		String pass_year=request.getParameter("pass_year");
		String Education=request.getParameter("Education");//a
		String Certification=request.getParameter("certification");
		String Certification_Place=request.getParameter("Certification_Place");
		
		
		
		Hrbean bn=new Hrbean();
		bn.setName(name);
		bn.setDate(dateDB);
		bn.setAddress(address1);
		bn.setAddress1(address2);
		bn.setContact(phone);
		bn.setEmail(email);
		bn.setGender(gender);
		bn.setDuration1(Duration);
		
		bn.setDesignation(Designation);
		bn.setType(type);
		bn.setBranch(branch);
		bn.setPass_year(pass_year);
		bn.setCirtification(Certification);
		bn.setCirtification_place(Certification_Place);
		bn.setQualification(Education);
		bn.setStatus(status);
		System.out.println(bn.getCirtification());
		
		Interface_Dao op=new OperationsDao();
		int y=op.insert_Student(bn);
		
		if(y==1) {
			request.setAttribute("a2", "Data added successfully");
			RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");
			rd.include(request, response);
//			response.sendRedirect("/HRML/Blank.jsp");
		}else if(y==2) {
			request.setAttribute("a2", "Duplicate record");
			RequestDispatcher rd=request.getRequestDispatcher("/Blank.jsp");
			rd.include(request, response);
		}
		}
		else  {
//			RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
//			rd.include(request, response);
			response.sendRedirect("/HRML/login.jsp");
			
		}
	}

}
