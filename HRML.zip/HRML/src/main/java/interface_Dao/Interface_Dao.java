package interface_Dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import beanclass.Hrbean;
import beanclass.Organization_bean;

public interface Interface_Dao {

	abstract int insert1(Hrbean bn) ;
	abstract Hrbean beforeupdate(Hrbean bn);
	abstract int delete(Hrbean bn);
	abstract int insert_organization(Organization_bean bn);
	abstract int update(Hrbean bn);
	abstract int update_Organization(Organization_bean bn);
	abstract Organization_bean Select_org(Organization_bean bn4);
	abstract int select_u_master(Organization_bean bn4);
	abstract ResultSet Organization_check_select();
	abstract int email_check(Organization_bean bn);
	abstract int username_check(Organization_bean bn);
	abstract Organization_bean select_u_master_Hr(Organization_bean bn2);
	abstract int insert_Student(Hrbean bn) ;
	abstract ResultSet select_student(Hrbean bn);
	abstract int delete_student(Hrbean bn) ;
	abstract Hrbean Beforeupdate_student(Hrbean bn);
	abstract int Update_student(Hrbean bn) ;
	abstract int contact_check(Organization_bean bn) ;
	abstract int student_contact_check(Organization_bean bn) ;
	abstract int student_email_check(Organization_bean bn) ;
	abstract int call_log(Hrbean bn) ;
	abstract ArrayList call_log_fetch(Hrbean bn);
	abstract int call_log_fetch1(Hrbean bn);
	abstract int recover_password(Hrbean bn);
	
}
